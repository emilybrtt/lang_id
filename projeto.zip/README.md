# Identificação de Idioma por Vetores de Frequência de Letras

**Projeto Final de Álgebra Linear — Insper**  
**Autores:** Gabriel Aguiar e Emily de Britto Gomes  
**Artigo (PDF):** [Link para o relatório/PDF aqui]

---

## Visão Geral
Este projeto aborda o problema real de Identificação de Idioma em Processamento de Linguagem Natural (PLN). A solução proposta utiliza modelagem puramente baseada em Álgebra Linear: transformamos textos em vetores de frequência de letras em um espaço de 26 dimensões e utilizamos a **Similaridade Cosseno** e a **Distância Euclidiana** para classificá-los em seis idiomas (PT, EN, ES, DE, FR, IT).

## Modelagem Matemática
1. **Vetorização:** Cada texto é limpo (remoção de caracteres especiais, conversão para minúsculas) e suas 26 letras do alfabeto latino são contadas.
2. **Normalização:** O vetor de contagem é dividido pelo número total de caracteres, gerando um vetor de frequência em **R^26**.
3. **Classificação:** O idioma de um texto de teste é determinado calculando o produto interno normalizado (cosseno) entre o vetor do texto e os vetores de referência (médias extraídas da Wikipedia) de cada idioma.

## Resultados e Limitações
- **Acurácia:** Alcançamos 42,6% com Similaridade Cosseno e 45,3% com Distância Euclidiana.
- **Limitações do Modelo Linear:** A matriz de confusão revelou que o modelo tem dificuldade em separar línguas românicas (Espanhol, Italiano e Português). Isso evidencia uma limitação da nossa hipótese inicial: as distribuições de frequência de letras isoladas não são perfeitamente linearmente separáveis para idiomas de mesma raiz gramatical, especialmente em textos curtos. 
- **Impacto no Problema Real:** Para aplicações reais (como roteamento de tickets de suporte), o modelo é leve e rápido, mas a acurácia baixa para textos curtos exigiria a adição de bigramas ou n-gramas para ser viável em produção.

## Comparação com a Referência
Nossa principal referência foi o trabalho de **Cavnar & Trenkle (1994)**. Enquanto eles utilizam perfis com os 300 n-gramas de caracteres mais frequentes (alcançando >99% de acurácia), nossa abordagem foca na simplicidade extrema (apenas 26 dimensões) e na interpretabilidade geométrica. Trocamos o poder preditivo absoluto pela clareza matemática e baixo custo computacional.

## Como Executar
**Pré-requisitos:** Python 3.8+ e as bibliotecas listadas no `requirements.txt`.

1. Clone o repositório:
   ```bash
   git clone [https://github.com/emilybrtt/lang_id.git](https://github.com/emilybrtt/lang_id.git)
    ```

2. Crie o ambiente virtual e instale as dependências:
    ```bash
    uv sync
    ```

3. Execute o script principal (o `uv run` já gerencia o ambiente virtual automaticamente):
   ```bash
   uv run main.py
    ```

## Estrutura do Repositório
- `data/`: Conjunto de dados extraídos da Wikipedia.
- `src/`: Scripts de coleta, limpeza e classificação.
- `notebooks/`: Análise exploratória e geração da matriz de confusão.
- `docs/`: Código LaTeX e PDF do relatório formato IEEE.